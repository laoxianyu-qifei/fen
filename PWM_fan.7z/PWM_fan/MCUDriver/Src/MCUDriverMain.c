/*
 * MCUDriverMain.c
 *
 *  Created on: Jan 4, 2024
 *      Author: 18199
 */

#include "MCUDriverMain.h"
#include "TIMFen.h"
#include "PWMUSART1.h"
#include "DS18B20.h"
#include "tim.h"
#include "iwdg.h"

uint8_t Temperature_Judgment;
/*************************************************************
** Function name:      MCUDriverMain_Init
** Descriptions:       芯片初始化
** Input parameters:   none
** Output parameters:  none
** Returned value:     none
** Created by:         none
** Created date:       none
*************************************************************/
void MCUDriverMain_Init(void)
{
	TIMFen_Init();
	PWMUSART1_Init();
	Temperature_Judgment = DS18B20_Init();
}

/*************************************************************
** Function name:      MCUDriverMain_Loop
** Descriptions:       芯片循环
** Input parameters:   none
** Output parameters:  none
** Returned value:     none
** Created by:         none
** Created date:       none
*************************************************************/
void MCUDriverMain_Loop(void)
{
	float temperature = 0;
	HAL_IWDG_Refresh(&hiwdg);
	  if(Temperature_Judgment == 0 && mode == 0)
	  {
		  temperature = DS18B20_GetTemp_SkipRom();
		  if(30>temperature)
			  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4,10);
		  else if(30<temperature && temperature<35)
			  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4,25);
		  else if(35<temperature && temperature<40)
			  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4,45);
		  else if(40<temperature && temperature<55)
			  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4,65);
		  else if(55<temperature)
			  __HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4,79);
		  HAL_Delay(100);
	  }
}

