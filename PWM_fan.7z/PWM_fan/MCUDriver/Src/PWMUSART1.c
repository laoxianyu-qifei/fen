/*
 * Motor1USART1.c
 *
 *  Created on: Jan 4, 2024
 *      Author: 18199
 */


#include "PWMUSART1.h"
#include "main.h"
#include "usart.h"
#include "tim.h"

uint8_t UART2_msg[10];//串口6消息
uint8_t mode = 0;
extern DMA_HandleTypeDef hdma_usart2_rx;

/*************************************************************
** Function name:       Motor1USART1_Init
** Descriptions:        串口通讯初始化
** Input parameters:    None
** Output parameters:   None
** Returned value:      None
** Remarks:             None
*************************************************************/
void PWMUSART1_Init(void)
{
	  HAL_UARTEx_ReceiveToIdle_DMA(&huart2, UART2_msg, sizeof(UART2_msg));
	  __HAL_DMA_DISABLE_IT(&hdma_usart2_rx,DMA_IT_HT);
}

/*************************************************************
** Function name:       HAL_UARTEx_RxEventCallback
** Descriptions:        串口接收中断初始化
** Input parameters:    None
** Output parameters:   None
** Returned value:      None
** Remarks:             None
*************************************************************/
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
	if(huart == &huart2)
	{
		if(UART2_msg[0] == 0XFF && UART2_msg[1]<0X51)
		{
			mode = 1;
			__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4,(uint16_t)UART2_msg[1]);
		}
//		HAL_UART_Transmit_DMA(&huart2,(uint8_t *)UART2_msg,sizeof(UART2_msg));
		HAL_UARTEx_ReceiveToIdle_DMA(&huart2, (uint8_t *)UART2_msg, sizeof(UART2_msg));
		__HAL_DMA_DISABLE_IT(&hdma_usart2_rx,DMA_IT_HT);
	}
}



