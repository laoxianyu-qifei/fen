#include "TIMFen.h"
#include "tim.h"
#include "usart.h"
#include "main.h"
#include "stdio.h"

//extern TIM_HandleTypeDef htim1;

void TIMFen_Init(void)
{
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_4);//初始化，开启PWM

    HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_1);
    HAL_TIM_IC_Start_IT(&htim2, TIM_CHANNEL_2);

	__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4,0);//设置比较寄存器CCRx的值，占空比=CCRx/ARRx 此处 CCRx=1000,ARRx=65536
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1,40);//设置比较寄存器CCRx的值，占空比=CCRx/ARRx 此处 CCRx=1000,ARRx=65536
//	__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2,40);//设置比较寄存器CCRx的值，占空比=CCRx/ARRx 此处 CCRx=1000,ARRx=65536
}


volatile uint32_t PWM_RisingCount = 0;
volatile uint32_t PWM_FallingCount = 0;
volatile float PWM_Duty = 0;
volatile float PWM_Period = 0;
volatile float PWM_Frequency = 0;
volatile float RPM = 0;
uint8_t buffer[20]; // 确保缓冲区足够大以容纳转换后的字符串
/**
*  @brief 定时器中断回调函数
*  @note  htim 定时器句柄
*/

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	if(htim == &htim2)
	{
		if(htim2.Channel == HAL_TIM_ACTIVE_CHANNEL_1)
		{
			/* 记录TIM2_CCR1的值 */
			PWM_RisingCount = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_1);

			if(PWM_RisingCount != 0 && PWM_FallingCount!= 0)
			{
				PWM_Duty        = (float)(PWM_FallingCount / PWM_RisingCount);//占空比
				PWM_Period      = PWM_RisingCount*0.000001f;                  //周期
				PWM_Frequency   = 1/PWM_Period;                               //频率
				PWM_RisingCount  = 0;
				PWM_FallingCount = 0;
				RPM = PWM_Frequency * 30.0;
				 //buffer[0] = (PWM_Frequency >> 8) & 0xFF; // 高字节存入第0位
				 //buffer[1] = PWM_Frequency & 0xFF;        // 低字节存入第1位
				 sprintf((char *)buffer, "%.2f", RPM);
				 HAL_UART_Transmit_DMA(&huart2,(uint8_t *)buffer,sizeof(buffer));
			}
		}
		else if(htim2.Channel == HAL_TIM_ACTIVE_CHANNEL_2)
		{
			/* 记录TIM2_CCR2的值 */
			PWM_FallingCount = HAL_TIM_ReadCapturedValue(&htim2,TIM_CHANNEL_2);
		}
	}
}





