#ifndef Motor1TIM1Pwm_h
#define Motor1TIM1Pwm_h

#include "stdint.h"

void TIMFen_Init(void);


#endif /* Motor1TIM1Pwm_h */
