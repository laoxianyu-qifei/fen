/*
 * MCUDriverMain.h
 *
 *  Created on: Jan 4, 2024
 *      Author: 18199
 */

#ifndef INC_MCUDRIVERMAIN_H_
#define INC_MCUDRIVERMAIN_H_

void MCUDriverMain_Init(void);
void MCUDriverMain_Loop(void);

#endif /* INC_MCUDRIVERMAIN_H_ */
