/*
 * Motor1USART1.h
 *
 *  Created on: Jan 4, 2024
 *      Author: 18199
 */

#ifndef INC_MOTOR1USART1_H_
#define INC_MOTOR1USART1_H_

#include "stdint.h"

void PWMUSART1_Init(void);

extern uint8_t UART1_msg[100];//串口1消息
extern uint8_t mode;

#endif /* INC_MOTOR1USART1_H_ */
