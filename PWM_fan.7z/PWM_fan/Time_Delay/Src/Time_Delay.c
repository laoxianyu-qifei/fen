/*
 * Time_Delay.c
 *
 *  Created on: Aug 26, 2024
 *      Author: 18199
 */

#include "Time_Delay.h"
#include "tim.h"

void delay_us(uint16_t nus)
{
	__HAL_TIM_SET_COUNTER(TIM_HANDLE, 0); //把计数器的值设置为0
	__HAL_TIM_ENABLE(TIM_HANDLE); //开启计数
	while (__HAL_TIM_GET_COUNTER(TIM_HANDLE) < nus); //每计数一次，就是1us，直到计数器值等于我们需要的时间
	__HAL_TIM_DISABLE(TIM_HANDLE); //关闭计数
}
/* USER CODE END 0 */

