/*
 * Time_Delay.h
 *
 *  Created on: Aug 26, 2024
 *      Author: 18199
 */

#ifndef INC_TIME_DELAY_H_
#define INC_TIME_DELAY_H_

#include "main.h"

/* USER CODE BEGIN 0 */
#define TIM_HANDLE &htim3 //定义这个是为了方便移植

void delay_us(uint16_t nus);

#endif /* INC_TIME_DELAY_H_ */
