/*
 * APPMain.h
 *
 *  Created on: Apr 15, 2024
 *      Author: 18199
 */

#ifndef INC_APPMAIN_H_
#define INC_APPMAIN_H_

#include "stdint.h"

void APPMain_Init(void);
void APPMain_Loop(void);



#endif /* INC_APPMAIN_H_ */
